import cv2

# เปิดกล้อง
cap = cv2.VideoCapture(0)

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        print("❌ ไม่สามารถเปิดกล้องได้")
        break

    cv2.imshow('Webcam', frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()

############################################
import cv2
import mediapipe as mp

# ตั้งค่า Mediapipe Hands Model
mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils

# เปิดกล้อง
cap = cv2.VideoCapture(0)

# ใช้ Mediapipe Hands Model
with mp_hands.Hands(min_detection_confidence=0.5, min_tracking_confidence=0.5) as hands:
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        # แปลงเป็น RGB
        image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        image.flags.writeable = False

        # ตรวจจับมือ
        results = hands.process(image)

        # แปลงกลับเป็น BGR
        image.flags.writeable = True
        image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)

        # วาดจุด Landmark (ไม่มีเส้นเชื่อม)
        if results.multi_hand_landmarks:
            for hand_landmarks in results.multi_hand_landmarks:
                for idx, landmark in enumerate(hand_landmarks.landmark):
                    h, w, c = image.shape
                    cx, cy = int(landmark.x * w), int(landmark.y * h)
                    
                    # วาดจุดบนมือ (วงกลมสีแดง)
                    cv2.circle(image, (cx, cy), 5, (0, 0, 255), -1)

        # แสดงผล
        cv2.imshow('Hand Detection', image)

        if cv2.waitKey(10) & 0xFF == ord('q'):
            break

cap.release()
cv2.destroyAllWindows()
########################################################################
import cv2
import mediapipe as mp

# ตั้งค่า Mediapipe Hands Model
mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils

# เปิดกล้อง
cap = cv2.VideoCapture(0)

# ใช้ Mediapipe Hands Model
with mp_hands.Hands(min_detection_confidence=0.5, min_tracking_confidence=0.5) as hands:
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        # แปลงเป็น RGB
        image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        image.flags.writeable = False

        # ตรวจจับมือ
        results = hands.process(image)

        # แปลงกลับเป็น BGR
        image.flags.writeable = True
        image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)

        # วาดจุด Landmark และเส้นเชื่อม (ก้างปลา)
        if results.multi_hand_landmarks:
            for hand_landmarks in results.multi_hand_landmarks:
                # วาด Landmark + Connections (ก้างปลา)
                mp_drawing.draw_landmarks(image, hand_landmarks, mp_hands.HAND_CONNECTIONS)

        # แสดงผล
        cv2.imshow('Hand Tracking (With Connections)', image)

        if cv2.waitKey(10) & 0xFF == ord('q'):
            break

cap.release()
cv2.destroyAllWindows()
#############################################################