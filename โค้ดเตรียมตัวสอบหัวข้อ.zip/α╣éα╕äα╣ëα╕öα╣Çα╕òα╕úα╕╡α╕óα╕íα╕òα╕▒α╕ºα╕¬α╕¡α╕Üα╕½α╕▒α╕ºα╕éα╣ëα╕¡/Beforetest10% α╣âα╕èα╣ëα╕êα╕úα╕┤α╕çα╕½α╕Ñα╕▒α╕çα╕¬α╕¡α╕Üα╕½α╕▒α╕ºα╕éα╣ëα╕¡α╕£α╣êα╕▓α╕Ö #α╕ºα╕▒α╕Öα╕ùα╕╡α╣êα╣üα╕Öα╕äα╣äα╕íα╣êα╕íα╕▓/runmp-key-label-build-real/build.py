import os
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping
from sklearn.model_selection import train_test_split

# Path for exported data
DATA_PATH = 'MP_Data'

# Actions that we try to detect
actions = np.array(['สวัสดี', 'ขอบคุณ', 'ใช่'])

# Number of frames per sequence
sequence_length = 30
feature_dim = 75 * 3  # ขนาดของ Keypoints (75 จุด x 3 มิติ)

# Create label map
label_map = {label: num for num, label in enumerate(actions)}
print("🎯 Label Mapping:", label_map)

# Load data
sequences, labels = [], []

for action in actions:
    action_path = os.path.join(DATA_PATH, action)
    
    if not os.path.exists(action_path):
        print(f"❌ Missing data folder: {action_path}")
        continue
    
    for sequence in sorted([d for d in os.listdir(action_path) if d.isdigit()], key=int):
        sequence_path = os.path.join(action_path, sequence)
        window = []
        
        for frame_num in range(sequence_length):
            npy_file = os.path.join(sequence_path, f"{frame_num}.npy")
            
            if os.path.exists(npy_file):
                res = np.load(npy_file)
            else:
                print(f"⚠️ Missing frame {frame_num} in {sequence_path}. Filling with zeros.")
                res = np.zeros((75, 3))  # (75, 3) แทนค่าที่ขาด
            
            window.append(res.flatten())  # แปลงเป็น (75*3=225,)
        
        if len(window) == sequence_length:
            sequences.append(window)
            labels.append(label_map[action])

# Convert to NumPy arrays
X = np.array(sequences)
y = to_categorical(labels, num_classes=len(actions)).astype(int)

# Check shapes
print(f"✅ Data Shape: X={X.shape}, y={y.shape}")  # ควรเป็น (None, 30, 225)

# Train/Test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1, random_state=42)
print(f"📊 Train/Test Split: X_train={X_train.shape}, X_test={X_test.shape}")

# Model definition with Dropout
model = Sequential([
    LSTM(64, return_sequences=True, activation='relu', input_shape=(sequence_length, feature_dim)),
    Dropout(0.2),
    LSTM(128, return_sequences=True, activation='relu'),
    Dropout(0.2),
    LSTM(64, return_sequences=False, activation='relu'),
    Dropout(0.2),
    Dense(64, activation='relu'),
    Dense(32, activation='relu'),
    Dense(len(actions), activation='softmax')
])

# Compile model with lower learning rate
model.compile(optimizer=Adam(learning_rate=0.0001), loss='categorical_crossentropy', metrics=['categorical_accuracy'])

# Early Stopping Callback
early_stop = EarlyStopping(monitor='val_loss', patience=20, restore_best_weights=True)

# Train model with batch size 32 and validation
model.fit(X_train, y_train, epochs=300, batch_size=32, validation_data=(X_test, y_test), callbacks=[early_stop])

# Model summary
model.summary()

# Save model
model.save('actionV3.h5')

print("✅ Model Training Complete! Model saved as 'action.h5'")
