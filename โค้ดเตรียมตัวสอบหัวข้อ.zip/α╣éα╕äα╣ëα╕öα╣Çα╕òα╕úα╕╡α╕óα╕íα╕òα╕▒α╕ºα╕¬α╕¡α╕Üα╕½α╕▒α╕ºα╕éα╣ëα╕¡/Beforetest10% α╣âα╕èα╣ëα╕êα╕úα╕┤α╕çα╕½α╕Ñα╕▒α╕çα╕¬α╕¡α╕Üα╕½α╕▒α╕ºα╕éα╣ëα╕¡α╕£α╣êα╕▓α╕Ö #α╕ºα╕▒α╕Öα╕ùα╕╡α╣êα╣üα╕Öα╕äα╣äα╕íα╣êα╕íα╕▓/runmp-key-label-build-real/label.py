import os
import numpy as np
from sklearn.model_selection import train_test_split
from tensorflow.keras.utils import to_categorical

# Path for exported data
DATA_PATH = 'MP_Data'

# Actions that we try to detect
actions = np.array(['สวัสดี', 'ขอบคุณ', 'ใช่'])

# Number of frames per sequence
sequence_length = 30
feature_dim = 75  # ขนาดข้อมูล feature ที่ extract มา

# สร้าง Label Map
label_map = {label: num for num, label in enumerate(actions)}
print("🎯 Label Mapping:", label_map)

# เตรียมข้อมูล
sequences, labels = [], []

for action in actions:
    action_path = os.path.join(DATA_PATH, action)
    
    # ตรวจสอบว่าโฟลเดอร์มีอยู่จริง
    if not os.path.exists(action_path):
        print(f"❌ Missing data folder: {action_path}")
        continue
    
    for sequence in sorted([d for d in os.listdir(action_path) if d.isdigit()], key=int):
        sequence_path = os.path.join(action_path, sequence)
        window = []
        
        for frame_num in range(sequence_length):
            npy_file = os.path.join(sequence_path, f"{frame_num}.npy")
            
            if os.path.exists(npy_file):
                res = np.load(npy_file)
            else:
                print(f"⚠️ Missing frame {frame_num} in {sequence_path}. Filling with zeros.")
                res = np.zeros((feature_dim, 3))  # เติมค่าศูนย์แทนข้อมูลที่หายไป
            
            window.append(res)
        
        # ตรวจสอบว่ามีครบ 30 เฟรมก่อนเพิ่มใน dataset
        if len(window) == sequence_length:
            sequences.append(window)
            labels.append(label_map[action])

# แปลงเป็น NumPy array
X = np.array(sequences)
y = to_categorical(labels, num_classes=len(actions)).astype(int)

# ตรวจสอบ Shape
print(f"✅ Data Shape: X={X.shape}, y={y.shape}")

# แบ่งข้อมูล Train/Test
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.05, random_state=42)

# ตรวจสอบ Shape ของชุดข้อมูลที่แบ่งแล้ว
print(f"📊 Train/Test Split: X_train={X_train.shape}, X_test={X_test.shape}, y_train={y_train.shape}, y_test={y_test.shape}")
