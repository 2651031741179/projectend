import os
import numpy as np

# Path for exported data, numpy arrays
DATA_PATH = os.path.join('MP_Data')

# Create main directory if not exists
if not os.path.exists(DATA_PATH):
    os.makedirs(DATA_PATH)

# Actions that we try to detect
actions = np.array(['สวัสดี', 'ขอบคุณ', 'ใช่'])

# Thirty videos worth of data
no_sequences = 30

# Videos are going to be 30 frames in length
sequence_length = 30

# Folder start
start_folder = 0

for action in actions:
    action_path = os.path.join(DATA_PATH, action)
    
    # Ensure action directory exists
    if not os.path.exists(action_path):
        os.makedirs(action_path)

    # Get the maximum existing directory number
    existing_dirs = [int(folder) for folder in os.listdir(action_path) if folder.isdigit()]
    dirmax = max(existing_dirs) if existing_dirs else start_folder

    for sequence in range(1, no_sequences + 1):
        new_folder_path = os.path.join(action_path, str(dirmax + sequence))
        os.makedirs(new_folder_path, exist_ok=True)
